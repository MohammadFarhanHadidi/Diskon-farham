<!DOCTYPE html>
<html>
<head>
    <title>Penjualan Barang</title>
</head>
<body>

    <h1>Input Penjualan Barang</h1>

    <form method="post">
        <label>No. Transaksi:</label>
        <input type="text" name="no_transaksi" ><br>

        <label>Nama Pembeli:</label>
        <input type="text" name="nama_pembeli"><br>

        <label>Nama Buku:</label>
        <input type="text" name="nama_buku"><br>

        <label>Jumlah Buku:</label>
        <input type="text" name="jumlah_buku"><br>

        <label>Harga:</label>
        <input type="text" name="harga"><br>

        <label>Diskon Belanja (%):</label>
        <input type="text" name="diskon_belanja"><br>

        <label>Diskon Transaksi (%):</label>
        <input type="text" name="diskon_transaksi"><br>

        <input type="submit" name="submit" value="Submit">

    </form>
    <?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $no_transaksi = $_POST["no_transaksi"];
    $nama_pembeli = $_POST["nama_pembeli"];
    $jumlah_buku = $_POST["jumlah_buku"];
    $harga = $_POST["harga"];
    $diskon_belanja = $_POST["diskon_belanja"];
    $diskon_transaksi = $_POST["diskon_transaksi"];

    $total_harga = ($jumlah_buku * $harga ) - ($harga * ($diskon_belanja / 100)) - ($harga * ($diskon_transaksi / 100));

    echo "<h2>Ringkasan Transaksi:</h2>";
    echo "<p>No. Transaksi: $no_transaksi</p>";
    echo "<p>Nama Pembeli: $nama_pembeli</p>";
    echo "<p>Diskon Belanja: $diskon_belanja %</p>";
    echo "<p>Diskon Transaksi: $diskon_transaksi %</p>";
    echo "<p>Total Harga: $total_harga</p>";

} else {

}
?>



</body>
</html>
